
export default {
  // Actions
  btn_delete:"Delete",
  btn_edit:"Edit",
  btn_actions:"Actions",
  btn_add_new:"Add New",
}
