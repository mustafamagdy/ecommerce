export default {
  // Actions
  btn_delete:"حذف",
  btn_edit:"تعديل",
  btn_actions:"وظائف",
  btn_add_new:"إضافة جديد",
}