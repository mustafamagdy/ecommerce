<template>
  <div class="row col-grow">
    <services-list class="col-12 col-sm-6"/>
  </div>
</template>

<script setup>
import servicesList from "./services-list.vue";
</script>